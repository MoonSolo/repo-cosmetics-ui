using HarmonyLib;
using UnityEngine;

namespace REPOCosmeticsDisplay
{
    // GameHooks is kept for future Phase 2 Harmony patches.
    // All rendering and input is now handled by UIComponent (a MonoBehaviour)
    // so no manual OnGUI hook is needed here.
    public static class GameHooks
    {
        // Reserved for future patches (e.g. reading real cosmetic unlock state from game classes)
    }
}
