using UnityEngine;
using System.Collections.Generic;

namespace REPOCosmeticsDisplay
{
    public class UIManager
    {
        private CosmeticsManager cosmeticsManager;
        private bool isVisible = false;

        // windowRect uses fixed position; Screen.width is not valid at construction time
        // so we initialize it lazily on first draw.
        private Rect windowRect;
        private bool windowRectInitialized = false;

        private Vector2 scrollPosition = Vector2.zero;

        // GUIStyles MUST be created inside OnGUI, not in a constructor,
        // because GUI.skin is only valid during an OnGUI call.
        private bool stylesInitialized = false;
        private GUIStyle headerStyle;
        private GUIStyle rarityStyle;

        private const float WINDOW_WIDTH  = 340f;
        private const float WINDOW_HEIGHT = 500f;
        private const float ITEM_HEIGHT   = 50f;
        private const float HEADER_HEIGHT = 30f;

        public UIManager(CosmeticsManager manager)
        {
            cosmeticsManager = manager;
            // Do NOT touch GUI.skin or GUIStyle here - this runs in Awake, not OnGUI.
        }

        // Called lazily from DrawUI(), which runs inside OnGUI - safe to use GUI.skin here.
        private void InitializeStyles()
        {
            headerStyle = new GUIStyle(GUI.skin.label)
            {
                fontSize  = 16,
                fontStyle = FontStyle.Bold,
                alignment = TextAnchor.MiddleCenter,
                normal    = { textColor = Color.white }
            };

            rarityStyle = new GUIStyle(GUI.skin.label)
            {
                fontSize  = 13,
                fontStyle = FontStyle.Bold,
                alignment = TextAnchor.MiddleLeft,
                padding   = new RectOffset(5, 5, 3, 3)
            };
        }

        public void Toggle()        => isVisible = !isVisible;
        public void SetVisible(bool visible) => isVisible = visible;
        public bool IsVisible => isVisible;

        public void DrawUI()
        {
            if (!isVisible)
                return;

            // Initialize styles the first time we actually draw (safe: we are inside OnGUI)
            if (!stylesInitialized)
            {
                InitializeStyles();
                stylesInitialized = true;
            }

            // Initialize window position now that Screen.width is valid
            if (!windowRectInitialized)
            {
                windowRect = new Rect(Screen.width - WINDOW_WIDTH - 10f, 100f, WINDOW_WIDTH, WINDOW_HEIGHT);
                windowRectInitialized = true;
            }

            try
            {
                windowRect = GUILayout.Window(9842, windowRect, DrawCosmeticsWindow,
                    "COSMETICS", GUILayout.Width(WINDOW_WIDTH), GUILayout.Height(WINDOW_HEIGHT));
            }
            catch (System.Exception ex)
            {
                Debug.LogError("[REPOCosmetics] Error drawing UI: " + ex.Message + "\n" + ex.StackTrace);
            }
        }

        private void DrawCosmeticsWindow(int windowID)
        {
            GUILayout.BeginVertical();

            // Summary header
            GUILayout.Label(
                string.Format("Unlocked: {0} / {1}",
                    cosmeticsManager.GetTotalUnlockedCount(),
                    cosmeticsManager.GetTotalCount()),
                headerStyle,
                GUILayout.Height(HEADER_HEIGHT));

            GUILayout.Space(4f);

            // Scrollable list
            scrollPosition = GUILayout.BeginScrollView(scrollPosition, GUILayout.ExpandHeight(true));

            DrawCosmeticsByRarity(CosmeticRarity.Common);
            DrawCosmeticsByRarity(CosmeticRarity.Uncommon);
            DrawCosmeticsByRarity(CosmeticRarity.Rare);
            DrawCosmeticsByRarity(CosmeticRarity.Legendary);

            GUILayout.EndScrollView();

            GUILayout.Space(4f);
            GUILayout.Label("Hold Tab to view | Release to hide",
                new GUIStyle(GUI.skin.label) { fontSize = 10, alignment = TextAnchor.MiddleCenter });

            GUILayout.EndVertical();

            // Allow dragging the window by its title bar
            GUI.DragWindow(new Rect(0f, 0f, 10000f, 20f));
        }

        private void DrawCosmeticsByRarity(CosmeticRarity rarity)
        {
            var cosmetics = cosmeticsManager.GetCosmeticsByRarity(rarity);
            if (cosmetics.Count == 0)
                return;

            int unlockedCount = cosmeticsManager.GetUnlockedCosmeticsByRarity(rarity).Count;
            Color rarityColor = cosmetics[0].GetRarityColor();

            // Rarity section header
            GUI.color = rarityColor;
            GUILayout.Label(
                string.Format("{0}  ({1}/{2})", cosmetics[0].GetRarityText(), unlockedCount, cosmetics.Count),
                rarityStyle,
                GUILayout.Height(22f));
            GUI.color = Color.white;

            foreach (var cosmetic in cosmetics)
                DrawCosmeticItem(cosmetic);

            GUILayout.Space(8f);
        }

        private void DrawCosmeticItem(Cosmetic cosmetic)
        {
            GUILayout.BeginHorizontal(GUILayout.Height(ITEM_HEIGHT));

            // Lock / unlock indicator
            if (cosmetic.IsUnlocked)
            {
                GUI.color = cosmetic.GetRarityColor();
                GUILayout.Label("\u2713", new GUIStyle(GUI.skin.label) { fontSize = 18 }, GUILayout.Width(22f));
                GUI.color = Color.white;
            }
            else
            {
                GUI.color = new Color(0.4f, 0.4f, 0.4f);
                GUILayout.Label("\u2717", new GUIStyle(GUI.skin.label) { fontSize = 18 }, GUILayout.Width(22f));
                GUI.color = Color.white;
            }

            // Name + ID column
            GUILayout.BeginVertical();
            Color nameColor = cosmetic.IsUnlocked ? Color.white : new Color(0.5f, 0.5f, 0.5f);
            GUILayout.Label(cosmetic.Name,
                new GUIStyle(GUI.skin.label) { fontSize = 12, fontStyle = FontStyle.Bold, normal = { textColor = nameColor } });
            GUILayout.Label("ID: " + cosmetic.ID,
                new GUIStyle(GUI.skin.label) { fontSize = 9, normal = { textColor = new Color(0.6f, 0.6f, 0.6f) } });
            GUILayout.EndVertical();

            GUILayout.EndHorizontal();
        }
    }
}
