using BepInEx;
using BepInEx.Logging;
using HarmonyLib;
using UnityEngine;
using TMPro;
using System.Collections;
using System.Reflection;

namespace REPOCosmeticsDisplay
{
    [BepInPlugin("com.repo.cosmetics.display", "REPO Cosmetics Display", "1.0.0")]
    public class REPOCosmeticsMod : BaseUnityPlugin
    {
        public static REPOCosmeticsMod Instance;
        public static ManualLogSource Log;

        private readonly Harmony harmony = new Harmony("com.repo.cosmetics.display");

        public static GameObject TextInstance;
        public static TextMeshProUGUI CosmeticsText;

        private static bool _reflectionResolved = false;
        private static object _metaSaveInstance = null;
        private static FieldInfo _fieldTotal     = null;
        private static FieldInfo _fieldUnlocked  = null;

        // Parallel arrays — index i of each array is one candidate pair
        private static readonly string[] CandidateTotals = {
            "cosmeticItemList",
            "allCosmeticItems",
            "cosmeticItems",
            "totalCosmeticItems"
        };
        private static readonly string[] CandidateUnlocked = {
            "cosmeticItemUnlockedList",
            "unlockedCosmeticItems",
            "unlockedCosmetics",
            "purchasedCosmeticItems"
        };

        private void Awake()
        {
            Instance = this;
            Log = Logger;
            Log.LogInfo("REPO Cosmetics Display loaded");
            harmony.PatchAll();
        }

        public static void ResolveReflection()
        {
            if (_reflectionResolved) return;
            _reflectionResolved = true;

            Assembly asm = null;
            foreach (var a in System.AppDomain.CurrentDomain.GetAssemblies())
            {
                if (a.GetName().Name == "Assembly-CSharp") { asm = a; break; }
            }
            if (asm == null) { Log.LogWarning("Assembly-CSharp not found"); return; }

            foreach (var type in asm.GetTypes())
            {
                FieldInfo instanceField = type.GetField("instance",
                    BindingFlags.Public | BindingFlags.Static);
                if (instanceField == null) continue;

                for (int i = 0; i < CandidateTotals.Length; i++)
                {
                    FieldInfo f1 = type.GetField(CandidateTotals[i],
                        BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
                    FieldInfo f2 = type.GetField(CandidateUnlocked[i],
                        BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);

                    if (f1 != null && f2 != null)
                    {
                        Log.LogInfo("CosmeticsDisplay: found fields '"
                            + CandidateTotals[i] + "' + '" + CandidateUnlocked[i]
                            + "' on type '" + type.Name + "'");
                        _fieldTotal       = f1;
                        _fieldUnlocked    = f2;
                        _metaSaveInstance = instanceField.GetValue(null);
                        return;
                    }
                }
            }

            // Nothing matched — dump cosmetic-related types so we can diagnose
            Log.LogWarning("CosmeticsDisplay: could not find cosmetic fields. Dumping cosmetic types:");
            foreach (var type in asm.GetTypes())
            {
                if (type.Name.ToLower().Contains("cosmetic") || type.Name.ToLower().Contains("metasave"))
                {
                    Log.LogWarning("  Type: " + type.Name);
                    foreach (var f in type.GetFields(
                        BindingFlags.Public | BindingFlags.NonPublic |
                        BindingFlags.Instance | BindingFlags.Static))
                    {
                        Log.LogWarning("    Field: " + f.Name + " (" + f.FieldType.Name + ")");
                    }
                }
            }
        }

        public static void ReadCosmeticCounts(ref int unlocked, ref int total)
        {
            try
            {
                // Instance may have been null at resolve time — retry
                if (_fieldTotal != null && _metaSaveInstance == null)
                {
                    FieldInfo inst = _fieldTotal.DeclaringType.GetField("instance",
                        BindingFlags.Public | BindingFlags.Static);
                    if (inst != null) _metaSaveInstance = inst.GetValue(null);
                }

                if (_metaSaveInstance == null || _fieldTotal == null || _fieldUnlocked == null)
                    return;

                ICollection totalList    = _fieldTotal.GetValue(_metaSaveInstance)    as ICollection;
                ICollection unlockedList = _fieldUnlocked.GetValue(_metaSaveInstance) as ICollection;

                if (totalList    != null) total    = totalList.Count;
                if (unlockedList != null) unlocked = unlockedList.Count;
            }
            catch (System.Exception ex)
            {
                Log.LogDebug("CosmeticsDisplay read failed: " + ex.Message);
            }
        }

        public static bool EnsureUI()
        {
            if (TextInstance != null) return true;

            GameObject hud     = GameObject.Find("Game Hud");
            GameObject taxHaul = GameObject.Find("Tax Haul");
            if (hud == null || taxHaul == null) return false;

            TMP_FontAsset font = taxHaul.GetComponent<TMP_Text>().font;

            TextInstance = new GameObject("CosmeticsDisplay");
            TextInstance.transform.SetParent(hud.transform, false);
            TextInstance.SetActive(false);

            CosmeticsText           = TextInstance.AddComponent<TextMeshProUGUI>();
            CosmeticsText.font      = font;
            CosmeticsText.fontSize  = 16f;
            CosmeticsText.color     = new Color(0.7882f, 0.9137f, 0.902f, 1f);
            CosmeticsText.alignment = TextAlignmentOptions.TopRight;

            RectTransform rt    = TextInstance.GetComponent<RectTransform>();
            rt.anchorMin        = new Vector2(1f, 1f);
            rt.anchorMax        = new Vector2(1f, 1f);
            rt.pivot            = new Vector2(1f, 1f);
            rt.anchoredPosition = new Vector2(-20f, -80f);
            rt.sizeDelta        = new Vector2(300f, 120f);

            Log.LogInfo("Cosmetics HUD text element created");
            return true;
        }
    }

    [HarmonyPatch(typeof(RoundDirector), "Update")]
    public static class RoundDirectorUpdatePatch
    {
        [HarmonyPostfix]
        public static void Postfix()
        {
            bool mapOpen = SemiFunc.InputHold((InputKey)8)
                        || (MapToolController.instance != null
                            && Traverse.Create(MapToolController.instance)
                                       .Field("mapToggled").GetValue<bool>());

            if (!mapOpen)
            {
                if (REPOCosmeticsMod.TextInstance != null)
                    REPOCosmeticsMod.TextInstance.SetActive(false);
                return;
            }

            REPOCosmeticsMod.ResolveReflection();
            if (!REPOCosmeticsMod.EnsureUI()) return;

            int unlocked = 0, total = 0;
            REPOCosmeticsMod.ReadCosmeticCounts(ref unlocked, ref total);

            REPOCosmeticsMod.TextInstance.SetActive(true);
            REPOCosmeticsMod.CosmeticsText.SetText(
                string.Format("Cosmetics: {0} / {1}", unlocked, total));
        }
    }
}
